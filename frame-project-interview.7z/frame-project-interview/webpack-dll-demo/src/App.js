import React from 'react'

class App extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return <p>This is App Component.</p>
    }
}

export default App
