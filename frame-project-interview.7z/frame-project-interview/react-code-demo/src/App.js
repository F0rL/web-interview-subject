import React from 'react'
// import BaseUse from './components/baseUse'
// import AdvancedUse from './components/advancedUse'
import ReduxUse from './components/reduxUse'
// import TodoList from './components/TodoLIst'

function App() {
  return (
    <div>
      {/* <BaseUse/> */}
      {/* <AdvancedUse/> */}
      <ReduxUse/>
      {/* <TodoList/> */}
    </div>
  );
}

export default App;
