import { sum } from './math'

const sumRes = sum(10, 20)
console.log('sumRes', sumRes)

console.log('other page')
