export const sum = (a, b) => {
    return a + b
}

export const mult = (a, b) => {
    return a * b
}

// ES6 Module 才能让 tree-shaking 生效
// commonjs 就不行
